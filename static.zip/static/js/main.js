document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.querySelector('.navbar');
    const searchToggle = document.getElementById('searchToggle');
    const searchOverlay = document.getElementById('searchOverlay');
    const searchClose = document.getElementById('searchClose');
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');

    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    if (searchToggle) {
        searchToggle.addEventListener('click', function() {
            searchOverlay.classList.add('active');
            searchInput.focus();
        });
    }

    if (searchClose) {
        searchClose.addEventListener('click', function() {
            searchOverlay.classList.remove('active');
            searchInput.value = '';
            searchResults.innerHTML = '';
        });
    }

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && searchOverlay.classList.contains('active')) {
            searchOverlay.classList.remove('active');
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    let searchTimeout;
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const query = this.value.trim();

            clearTimeout(searchTimeout);

            if (query.length < 2) {
                searchResults.innerHTML = '';
                return;
            }

            searchTimeout = setTimeout(async () => {
                try {
                    searchResults.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Searching...</div>';

                    const response = await fetch(`/search?q=${encodeURIComponent(query)}`);
                    const data = await response.json();

                    if (data.movies && data.movies.length > 0) {
                        searchResults.innerHTML = data.movies.map(movie => `
                            <a href="/movie/${movie.id}" class="search-result-item">
                                ${movie.poster_url 
                                    ? `<img src="${movie.poster_url}" alt="${movie.title}">`
                                    : `<div style="width: 50px; height: 75px; background: var(--bg-tertiary); display: flex; align-items: center; justify-content: center; border-radius: 4px;"><i class="fas fa-film" style="color: var(--text-muted);"></i></div>`
                                }
                                <div class="search-result-info">
                                    <h4>${movie.title}</h4>
                                    <p>${movie.genres ? movie.genres.slice(0, 2).join(', ') : ''} ${movie.release_date ? '• ' + movie.release_date.substring(0, 4) : ''}</p>
                                </div>
                            </a>
                        `).join('');
                    } else {
                        searchResults.innerHTML = '<p class="no-results">No movies found. Try a different search term.</p>';
                    }
                } catch (error) {
                    console.error('Search error:', error);
                    searchResults.innerHTML = '<p class="error">Something went wrong. Please try again.</p>';
                }
            }, 300);
        });
    }

    const scrollContainers = document.querySelectorAll('.movies-scroll');
    scrollContainers.forEach(container => {
        let isDown = false;
        let startX;
        let scrollLeft;

        container.addEventListener('mousedown', (e) => {
            isDown = true;
            container.style.cursor = 'grabbing';
            startX = e.pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
        });

        container.addEventListener('mouseleave', () => {
            isDown = false;
            container.style.cursor = 'grab';
        });

        container.addEventListener('mouseup', () => {
            isDown = false;
            container.style.cursor = 'grab';
        });

        container.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - container.offsetLeft;
            const walk = (x - startX) * 2;
            container.scrollLeft = scrollLeft - walk;
        });

        container.style.cursor = 'grab';
    });

    const lazyImages = document.querySelectorAll('img[loading="lazy"]');
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        });

        lazyImages.forEach(img => {
            imageObserver.observe(img);
        });
    }
});

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}
